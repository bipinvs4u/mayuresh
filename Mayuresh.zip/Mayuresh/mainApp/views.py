from django.shortcuts import render
from django.http import HttpResponse
from .models import Setting
from .models import *
import datetime
from django.utils import timezone
from django.core.exceptions import ObjectDoesNotExist

def home(req):   
    current_date_time = timezone.now().replace(microsecond=0)
    print(current_date_time)
    s = Setting.objects.filter(day__gte=current_date_time).order_by('day').first()
   
    # getting graha number
    su=s.surya
    ch=s.chandra
    ma=s.mangala
    bu=s.budha
    br=s.brihaspati
    shu=s.shukra
    sha=s.shani
    rah=s.rahu
    ke=s.ketu
    # set display labels
    # right hand side of the equal to can be changed to sanskrit letter or image
    # Eg for image "<img src='{%static image/su.jpg%}' height='40px' width='40px'>"    #where su.jpg is the name of the image file stored inside static/image folder.
    sud="SU"
    chd="CH"
    mad="MA"
    bud="BU"
    brd="BR"
    shud="SHU"
    shad="SHA"
    rahd="RAH"
    ked="KE"

    sul=f"su{su}"           
    chl=f"ch{ch}"            
    mal=f"ma{ma}"        
    bul=f"bu{bu}"        
    brl=f"br{br}"
    shul=f"br{shu}"
    shal=f"br{sha}"
    rahl=f"br{rah}"
    kel=f"br{ke}"

    sudl=f"sud{su}"           
    chdl=f"chd{ch}"            
    madl=f"mad{ma}"        
    budl=f"bud{bu}"        
    brdl=f"brd{br}"        
    shudl=f"shud{shu}"        
    shadl=f"shad{sha}"        
    rahdl=f"rahd{rah}"        
    kedl=f"ked{ke}"
    
    context_={
        sul:su,sudl:sud,
        chl:ch,chdl:chd,
        mal:ma,madl:mad,
        brl:br,brdl:brd,
        bul:bu,budl:bud,
        shul:shu,shudl:shud,
        shal:sha,shadl:shad,
        rahl:rah,rahdl:rahd,
        kel:ke,kedl:ked,
    }
    print(context_) 
    return render(req,'home.html',context_)

def result(req,graha,id):
    try:
        if graha=='su':  
            res = Surya.objects.filter(id=id).get()

        elif graha=='ch':
            res = Chandra.objects.filter(id=id).get()
        
        elif graha=='ma':
            res = Mangala.objects.filter(id=id).get()
        
        elif graha=='br':
            res = Brihaspati.objects.filter(id=id).get()
        
        elif graha=='bu':
            res = Budha.objects.filter(id=id).get()
        
        elif graha=='shu':
            res = Shukra.objects.filter(id=id).get()
        
        elif graha=='sha':
            res = Shani.objects.filter(id=id).get()

        elif graha=='rah':
            res = Rahu.objects.filter(id=id).get()

        elif graha=='ke':
            res = Ketu.objects.filter(id=id).get()
        
        else:
            res = None
    except ObjectDoesNotExist:
        res = None
        response="<p class='text-danger'>Sorry No result found</p>"
     
    if res:    
        response = f"<label><em>Brihajjatakam : </em></label>{res.Brihajjatakam}<br>\
                    <label><em>Phaladeepika : </em></label>{res.Phaladeepika}</br>\
                    <label><em>Camatkara chintamani : </em></label>{res.Camatkara_Chintamani}\
                "
    else:
        reponse = "<p class='text-danger'>Sorry No result found</p>"
    return HttpResponse(response)

def about(req):
    return render(req,'about.html')
def guide(req):
    return render(req,'guide.html')
