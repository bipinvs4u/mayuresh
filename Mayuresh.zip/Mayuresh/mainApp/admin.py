from django.contrib import admin
from .models import *
# Register your models here.
# admin.site.register(Surya)
# admin.site.register(Chandra)
# admin.site.register(Mangala)
# admin.site.register(Budha)
# admin.site.register(Brihaspati)
# admin.site.register(Shukra)
# admin.site.register(Shani)
# admin.site.register(Rahu)
# admin.site.register(Ketu)
# admin.site.register(Setting)

from django.utils.text import capfirst

class CustomAdminSite(admin.AdminSite):
    def get_app_list(self, request):
        app_dict = self._build_app_dict(request)
        for app_name, app in app_dict.items():
            app['models'].sort(key=lambda x: self.get_model_order(x['object_name']))
        return sorted(app_dict.values(), key=lambda x: x['name'].lower())

    def get_model_order(self, model_name):
        order = [
            'Surya', 'Chandra', 'Mangala', 'Budha', 'Brihaspati',
            'Shukra', 'Shani', 'Rahu', 'Ketu', 'Setting'
        ]
        try:
            return order.index(model_name)
        except ValueError:
            return len(order)

custom_admin_site = CustomAdminSite(name='custom_admin')

# Register models with the custom admin site
# @admin.register(Surya)
# class SuryaAdmin(admin.ModelAdmin):
#     class Meta:
#         model=Surya
#         list_display = ('day','status')
    

custom_admin_site.register(Surya)
custom_admin_site.register(Chandra)
custom_admin_site.register(Mangala)
custom_admin_site.register(Budha)
custom_admin_site.register(Brihaspati)
custom_admin_site.register(Shukra)
custom_admin_site.register(Shani)
custom_admin_site.register(Rahu)
custom_admin_site.register(Ketu)
custom_admin_site.register(Setting)