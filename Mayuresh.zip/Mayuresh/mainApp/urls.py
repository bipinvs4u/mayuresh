
from django.contrib import admin
from django.urls import path,include
from . import views
from .admin import custom_admin_site
urlpatterns = [    
    path('admin/', custom_admin_site.urls),
    path('',views.home,name="home"),    
    path('<graha>/<id>/',views.result,name="result"),
    path('about/',views.about,name='about'),
    path('guide/',views.guide,name='guide'),
    
]
