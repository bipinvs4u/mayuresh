from django.db import models

# Create your models here.
class Setting(models.Model):
    CHOICES=(('1','1'),('2','2'),('3','3'),('4','4'),('5','5'),('6','6'),('7','7'),('8','8'),('9','9'),('10','10'),('11','11'),('12','12'),('0','0'))
    day = models.DateTimeField()
    surya = models.TextField(max_length=2,choices=CHOICES)
    chandra = models.TextField(max_length=2,choices=CHOICES)
    mangala = models.TextField(max_length=2,choices=CHOICES)
    budha = models.TextField(max_length=2,choices=CHOICES)
    brihaspati = models.TextField(max_length=2,choices=CHOICES)
    shukra = models.TextField(max_length=2,choices=CHOICES)
    shani = models.TextField(max_length=2,choices=CHOICES)
    rahu = models.TextField(max_length=2,choices=CHOICES)
    ketu = models.TextField(max_length=2,choices=CHOICES)
    description = models.TextField(max_length=255,null=True,blank=True)
    status=models.BooleanField(default=False)
    def __str__(self):
        return f"{self.day} {self.status}"
class Surya(models.Model):
    Brihajjatakam =models.TextField(max_length=255)
    Phaladeepika =models.TextField(max_length=255)
    Camatkara_Chintamani =models.TextField(max_length=255)
    def __str__(self):
        return f"{self.id}-{self.Brihajjatakam}"
class Chandra(models.Model):
    Brihajjatakam =models.TextField(max_length=255)
    Phaladeepika =models.TextField(max_length=255)
    Camatkara_Chintamani =models.TextField(max_length=255)
    def __str__(self):
        return f"{self.id}-{self.Brihajjatakam}"
class Mangala(models.Model):
    Brihajjatakam =models.TextField(max_length=255)
    Phaladeepika =models.TextField(max_length=255)
    Camatkara_Chintamani =models.TextField(max_length=255)
    def __str__(self):
        return f"{self.id}-{self.Brihajjatakam}"
class Budha(models.Model):
    Brihajjatakam =models.TextField(max_length=255)
    Phaladeepika =models.TextField(max_length=255)
    Camatkara_Chintamani =models.TextField(max_length=255)
    def __str__(self):
        return f"{self.id}-{self.Brihajjatakam}"
class Brihaspati(models.Model):
    Brihajjatakam =models.TextField(max_length=255)
    Phaladeepika =models.TextField(max_length=255)
    Camatkara_Chintamani =models.TextField(max_length=255)
    def __str__(self):
        return f"{self.id}-{self.Brihajjatakam}"
class Shukra(models.Model):
    Brihajjatakam =models.TextField(max_length=255)
    Phaladeepika =models.TextField(max_length=255)
    Camatkara_Chintamani =models.TextField(max_length=255)
    def __str__(self):
        return f"{self.id}-{self.Brihajjatakam}"
class Shani(models.Model):
    Brihajjatakam =models.TextField(max_length=255)
    Phaladeepika =models.TextField(max_length=255)
    Camatkara_Chintamani =models.TextField(max_length=255)
    def __str__(self):
        return f"{self.id}-{self.Brihajjatakam}"
class Rahu(models.Model):
    Brihajjatakam =models.TextField(max_length=255)
    Phaladeepika =models.TextField(max_length=255)
    Camatkara_Chintamani =models.TextField(max_length=255)
    def __str__(self):
        return f"{self.id}-{self.Brihajjatakam}"
class Ketu(models.Model):
    Brihajjatakam =models.TextField(max_length=255)
    Phaladeepika =models.TextField(max_length=255)
    Camatkara_Chintamani =models.TextField(max_length=255)
    def __str__(self):
        return f"{self.id}-{self.Brihajjatakam}"
